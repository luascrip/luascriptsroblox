--[[
You Installed fαкєѕтєℓℓα!
Unpack the folder sayed: FAKEStella


the scripts -> https://luascrip.github.io/luascriptsroblox/ <-


	info:
	Created By: luascrip0
	Textbox: Monaco
	API: OxygenU_API
	Version: BETA
]]