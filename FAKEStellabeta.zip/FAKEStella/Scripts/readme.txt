--[[
	Hello! Welcome To FAKEStella BETA!
	You Can Test The OwlHub! It's Works!!!
--]]
print("FAKEStella Works!")